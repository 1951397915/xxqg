//开启截屏功能
if (!requestScreenCapture()) {
    console.log("请求截图失败");
    exit();
}
//toastLog(" 请在无障碍中选择本 APP");
auto.waitFor();

importClass(android.database.sqlite.SQLiteDatabase);
var path = files.path("tiku.db");
console.setGlobalLogConfig({ "file": "/sdcard/qgxx/运行日志.txt" });
let storage = storages.create("form") //本地存储文件建立
let formDefault = {//默认选择项为空
    challenge_quiz: true,
    daily_quiz: true,
    sr_quiz: true,
    zsy_quiz: true,
    weekly_quiz: false,
    special_quiz: false,
    article_quiz: true,
    video_quiz: true,
    local_quiz: true,
    weekly_scroll: 5,
    spec_scroll: 5,
    //delayed_exe: false,
    challenge_all: false,
    dian_full: false,
    self_kill: false,
    battle_delay: 500
}
let form = storage.get("form", formDefault);

//推送
var xxset = {
    "url": "http://pushplus.hxtrip.com/send", //定义微信推送对象 url+"?token="+token+"&title="+title+"&content="+content
    "token": "98e04553d278461abc00977c639c3396", //在pushplus网站登录可以找到自己的token
    "wxpost": 1    //是否微信推送
}
var DLog;//记录内容推送用

var aCount = 12;//文章默认学习篇数
var vCount = 12;//小视频默认学习个数
var cCount = 2;//收藏+分享+评论次数

var aTime = 30;//每篇文章学习-30秒 30*12≈360秒=6分钟
var vTime = 17;//每个小视频学习60秒
var rTime = 360;//音视频时长-6分钟

var dyNum = 2;//订阅 2
var commentText = ["支持党，支持国家！", "为实现中华民族伟大复兴而不懈奋斗！", "不忘初心，牢记使命", "总书记说到了心坎上。"];//评论内容，随机发送，可自行修改，大于5个字便计分
var aCat = ["推荐", "要闻", "新思想"];
var current_date = getTodayDateString();//获取当天日期字符串
var vCat = ["第一频道", "学习视频", "看党史"];
var lCount = 1;//挑战答题轮数
var qCount = random(5, 8);//挑战答题每轮答题数(5~8随机)
var zCount = 2;//四人赛答题轮数
var myScores = {};//分数
var myDiandian = {}; //点点通
var idNumber = ""; //学号
var allRun = false;

var specialQuest = ["选择词语的正确词形。", "选择正确的读音。", "选择正确的读音", "下列不属于二十四史的是。", "下列不属于“十三经”的是。", "下列说法正确的是。"];
var chutiIndexArray = ["出题：", "（出题单位：", "来源：", "（来源：", "推荐："];//去除题目中尾巴（非题目内容） 

let window = floaty.window(
    <vertical>
        <button id="move" text=" 移动 " w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="switchXX" text=" 切到 强国 " w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="all" text="随机执行" w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="ra" text="文章学习" w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="rv" text="视频学习" w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="dq" text="各类答题" w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="stop" text=" 停止 " w="90" h="35" bg="#77ffffff" textSize="10sp" />
        <button id="exit" text=" 退出悬浮窗 " w="90" h="35" bg="#77ffffff" textSize="10sp" />
    </vertical>
);

let deviceWidth = device.width;
let deviceHeight = device.height;
window.setPosition(deviceWidth * 0.75, deviceHeight * 0.5);
setInterval(() => {
}, 1000);


let wx, wy, downTime, windowX, windowY;
// 这个函数是对应悬浮窗的移动
window.move.setOnTouchListener(function (view, event) {
    switch (event.getAction()) {
        case event.ACTION_DOWN:
            wx = event.getRawX();
            wy = event.getRawY();
            windowX = window.getX();
            windowY = window.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            // 如果按下的时间超过 xx 秒判断为长按，调整悬浮窗位置
            if (new Date().getTime() - downTime > 300) {
                window.setPosition(windowX + (event.getRawX() - wx), windowY + (event.getRawY() - wy));
            }
            return true;
        case event.ACTION_UP:
            // 手指弹起时如果偏移很小则判断为点击
            if (Math.abs(event.getRawY() - wy) < 30 && Math.abs(event.getRawX() - wx) < 30) {
                toastLog(" 长按调整位置 ")
            }
            return true;
    }
    return true;
});

window.switchXX.click(() => {
    toastLog(" 切换到学习强国APP...");
    if (!launchApp("学习强国"))//启动学习强国app
    {
        console.error("找不到学习强国App!");
        return;
    }
});


// 这个函数是对应悬浮窗的退出
window.exit.click(() => {
    toastLog(" 退出！");
    exit();
});


var thread = null;
window.all.click(function () {
    if (thread != null && thread.isAlive()) {
        alert("注意", "脚本正在运行，请结束之前进程");
        return;
    }

    thread = threads.start(function () {
        allRun = true;
        main();
        threads.shutDownAll();
        console.hide();
        //engines.stopAll();
    });
});

window.ra.click(function () {
    auto.waitFor();//等待获取无障碍辅助权限
    if (thread != null && thread.isAlive()) {
        alert("注意", "脚本正在运行，请结束之前进程");
        return;
    }
    thread = threads.start(function () {
        console.setPosition(0, device.height / 2);//部分华为手机console有bug请注释本行
        console.show();//部分华为手机console有bug请注释本行
        article_study();
        threads.shutDownAll();
        console.hide();
        //engines.stopAll();
    });
});

window.rv.click(function () {
    auto.waitFor();//等待获取无障碍辅助权限
    if (thread != null && thread.isAlive()) {
        alert("注意", "脚本正在运行，请结束之前进程");
        return;
    }
    thread = threads.start(function () {
        console.setPosition(0, device.height / 2);//部分华为手机console有bug请注释本行
        console.show();//部分华为手机console有bug请注释本行
        video_study();
        threads.shutDownAll();
        console.hide();
        //engines.stopAll();
    });
});

window.dq.click(function () {
    auto.waitFor();//等待获取无障碍辅助权限
    if (thread != null && thread.isAlive()) {
        alert("注意", "脚本正在运行，请结束之前进程");
        return;
    }
    thread = threads.start(function () {
        answerQuestion();
        threads.shutDownAll();
        console.hide();
        //engines.stopAll();
    });
});


window.stop.click(function () {
    if (thread != null && thread.isAlive()) {
        threads.shutDownAll();
        toast("停止运行！")
        console.hide();
    }
    else {
        toast("没有线程在运行！")
    }
});

//推送
//日志记录和弹出提示
function detailLog(str, log) {
    var time = new java.text.SimpleDateFormat('HH:mm:ss').format(new Date());
    //str = str + "<br/>\n" + time + " " + log;
    str = str + "<br/>" + time + " " + log;
//    console.log(log);
//    toast(log);
    return str;
}
//微信推送
function pushwx(title, content) {
    //发送日志post
    var wxsend = http.post(xxset.url, {
        "token": xxset.token,
        "title": title,
        "content": content,
        headers: { "Content-Type": "application/json" }
    });
    return wxsend;
}

function main() {
    if (!judge_tiku_existence()) {//题库不存在则退出
        return;
    }

    auto.waitFor();//等待获取无障碍辅助权限

    start_app();//启动app
    //延后执行
    /*if (form.delayed_exe == true) {
        var targetTime = new Date();
        targetTime.setDate(targetTime.getDate() + 1);
        targetTime.setHours(0);
        targetTime.setMinutes(0);
        var time = new Date();
        while (time < targetTime) {
            toast("还有" + (targetTime-time)/1000 +"秒开始");
            sleepTime = (targetTime-time)
            if (sleepTime > 10000) {
                sleepTime = 10000;
            }
            sleep(sleepTime+1);
            time = new Date();
        }
    }*/

    var start = new Date().getTime();//程序开始时间 

    getUserId(); //获取学号和用户名
    getScores(); //获取积分
    cleanLearnedArticle();

    //先把视听给做了
    if (form.video_quiz && vCount > 0) {
        video_study();
    }

    if ((rTime > 0)) {
        listenToRadio(); //听电台广播
    }

    var startNumber = [1, 2, 3, 4, 5, 6, 7, 8];
    startNumber = randSort(startNumber);
    for (let num of startNumber) {
        switch (num) {
            case 1:
                if (form.article_quiz && aCount > 0)
                    article_study();
                break;
            case 2:
                if (form.zsy_quiz && myScores['四人赛'] < 2)
                    fourBattle();
                break;
            case 3:
                if (form.local_quiz && myScores['本地频道'] < 1)
                    localChannel1();
                break;
            case 4:
                if (form.daily_quiz && myScores['每日答题'] < 5)
                    dailyQuestion();
                break;
            case 5:
                if (form.challenge_quiz && lCount > 0)
                    challengeQuestion()
                break;
            case 6:
                if (form.weekly_quiz && myScores['每周答题'] < 2)
                    weeklyQuestion();
                break;
            case 7:
                if (form.special_quiz && myScores['专项答题'] < 2)
                    zhuangxiangQuest()
                break;
            case 8:
                if (form.sr_quiz && myScores['双人对战'] < 1)
                    doubleBattle();
                break;
        }
    }


    getScores();
    if ((rTime > 0)) {
        listenToRadio(); //继续听电台
        radio_timing(0, rTime); //广播剩余需收听时间
    }

    while ((aCount != 0) || (vCount != 0)) {
        if (vCount != 0) {
            console.log('小视频学习')
            videoStudy_bailing(vCount, vTime); //看视频
        }

        if (aCount != 0) {
            console.log('文章学习')
            article_study();
        }
        getScores();
    }

    var end = new Date().getTime();
    console.log("运行结束,共耗时" + (parseInt(end - start)) / 1000 + "秒");
    var titlemsg = "学习";
    DLog = "《" + new java.text.SimpleDateFormat('yyyy-MM-dd').format(new Date()) + " | " + "学习情况" + "》";
    let xxScores1 = Number(textStartsWith("今日已累积").findOnce().text().substr(6, 1));//第六位
          //  log(xxScores1)
            let xxScores2 = Number(textStartsWith("今日已累积").findOnce().text().substr(7, 1));//第七位
           // log(xxScores2)
            if (!isNaN(xxScores2)) {//第七位为数字，即得分为10分以上
                getxxScores = xxScores1 * 10 + xxScores2;
                //log(getxxScores)
            } else {//第七位不为数字，即得分为10分以下
                getxxScores = xxScores1;
             
            }
            getgoalScores = Number(text("成长总积分").findOnce().parent().children()[3].text());//成长总积分
    //log(getgoalScores)
    DLog = detailLog(DLog, "今日已学习" + getxxScores + "积分");
    DLog = detailLog(DLog, "总积分" + getgoalScores );
    DLog = detailLog(DLog, "用户：" + name);
    DLog = detailLog(DLog, "运行结束,共耗时" + (parseInt(end - start)) / 1000 + "秒");
    //机器码
    var jqm=device.getAndroidId();
    DLog = detailLog(DLog, "机器码:" + jqm);
    //唯一标识码
    var bsm=device.fingerprint
    DLog = detailLog(DLog, "标识码:" + bsm);
    //获取电量
    var battery = device.getBattery();
    DLog = detailLog(DLog, "设备当前电量：" + battery);
    if (battery < 30) {
        //发送需要充电通知
        DLog = detailLog(DLog, "需要充电了");
    }


    //微信推送学习情况
    if (xxset.wxpost) {
        var nowtime = new java.text.SimpleDateFormat('HH:mm:ss').format(new Date());
        var title = nowtime + " 已完成" + titlemsg;
        var content = DLog;
        var wxsend = pushwx(title, content);
        //发送成功与否？
        if (wxsend.statusCode == 200) {
            DLog = detailLog(DLog, "--==  成功  ==--"); //成功发送日志
        } else {
            DLog = detailLog(DLog, "+++ 失败，请检查 +++");
        }
    }
    threads.shutDownAll();
    console.hide();
    engines.stopAll();
    exit();
}


/** 
 * @description: 启动app
 * @param: null
 * @return: null
 */
function start_app() {
    console.setPosition(0, device.height / 2);//部分华为手机console有bug请注释本行
    console.show();//部分华为手机console有bug请注释本行
    console.log("启动学习强国");
    if (!launchApp("学习强国")) {//启动学习强国app
        console.error("找不到学习强国App!");
        return;
    }

    sleep(3000)
    goMainPage();
}

/**
 * @description: 数组洗牌算法
 * @param: 数组arr
 * @return: 随机排序后的数组arr
 */
function randSort(arr) {
    for (i = 0, len = arr.length; i < len; i++) {
        var rand = parseInt(Math.random() * len);
        var temp = arr[rand];
        arr[rand] = arr[i];
        arr[i] = temp;
    }
    return arr;
}

/**
 * @description: 每日答题
 * @param: null
 * @return: null
 */
function dailyQuestion() {
    goMainPage();
    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("每日答题").exists());
    sleep(1000);
    text("每日答题").click();
    console.verbose("开始每日答题");
    sleep(2000);
    let dlNum = 0; //每日答题轮数
    while (true) {
        dailyQuestionLoop();
        if (text("再来一组").exists()) {
            sleep(2000);
            dlNum++;
            if (!text("领取奖励已达今日上限").exists()) {
                text("再来一组").click();
                console.warn("第" + (dlNum + 1).toString() + "轮答题:");
                sleep(1000);
            } else {
                console.verbose("每日答题结束！");
                text("返回").click();
                while (!desc("工作").exists()) {
                    back();
                    sleep(1000);
                }
                break;
            }
        }
    }
}

/**
 * @description: 每周答题
 * @param: null
 * @return: null
 */
function weeklyQuestion() {
    let h = device.height;//屏幕高
    let w = device.width;//屏幕宽
    let x = (w / 3) * 2;//横坐标2分之3处
    let h1 = (h / 6) * 5;//纵坐标6分之5处
    let h2 = (h / 6);//纵坐标6分之1处
    goMainPage();

    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("每周答题").exists());
    sleep(1000);
    text("每周答题").click();
    console.verbose("开始每周答题");

    let i = 0;//参考订阅的翻页，只进行一次点击
    let flag = false;
    while (!flag) {
        if (text("未作答").exists()) {
            text("未作答").click();
            flag = true;
            break;
        } else if (text("您已经看到了我的底线").exists()) {
            console.log("没有可作答的每周答题了,退出!!!")
            break;
        } else {
            if (i < form.weekly_scroll) {
                delay(0.5);
                swipe(x, h1, x, h2, 500);//往下翻（纵坐标从5/6处滑到1/6处）
                i++;
                console.log("第" + i + "次滑动查找未作答的每周答题")
                delay(0.5);

            } else {
                break;
            }
        }
    }

    while (flag) {
        delay(1)
        while (!(textStartsWith("填空题").exists() || textStartsWith("多选题").exists() || textStartsWith("单选题").exists())) {
            console.error("没有找到题目！请检查是否进入答题界面！");
            delay(2);
        }
        dailyQuestionLoop();
        if (text("再练一次").exists()) {
            console.log("每周答题结束，返回！")
            break;
        } else if (text("查看解析").exists()) {
            console.log("每周答题结束，返回！")
            break;
        } else if (text("再来一组").exists()) {
            console.log("每周答题结束，返回！")
            break;
        }
    }
    //回退返回主页 
    goMainPage();
}

/**
 * @description: 专项答题
 * @param: null
 * @return: null
 */
function zhuangxiangQuest() {
    let h = device.height;//屏幕高
    let w = device.width;//屏幕宽
    let x = (w / 3) * 2;//横坐标2分之3处
    let h1 = (h / 6) * 5;//纵坐标6分之5处
    let h2 = (h / 6);//纵坐标6分之1处
    goMainPage();

    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("专项答题").exists());
    sleep(1000);
    text("专项答题").click();
    console.verbose("开始专项答题");

    let i = 0;//参考订阅的翻页，只进行一次点击
    let flag = false;

    while (!flag) {
        if (text("继续答题").exists()) {
            text("继续答题").click();
            flag = true;
            break;
        } else if (text("开始答题").exists()) {
            text("开始答题").click();
            flag = true;
            break;
        } else if (text("您已经看到了我的底线").exists()) {
            console.log("没有可作答的专项答题了,退出!!!")
            goMainPage();
            break;
        } else {
            if (i < form.spec_scroll) {
                delay(0.5);
                swipe(x, h1, x, h2, 500);//往下翻（纵坐标从5/6处滑到1/6处）
                i++;
                delay(0.5);
                console.log("第" + i + "次滑动查找未作答的专项答题")
            } else {
                break;
            }
        }
    }

    while (flag) {
        delay(1)
        while (!(textStartsWith("填空题").exists() || textStartsWith("多选题").exists() || textStartsWith("单选题").exists())) {
            console.error("没有找到题目！请检查是否进入答题界面！");
            delay(2);
        }
        dailyQuestionLoop();
        if (text("再练一次").exists()) {
            console.log("专项答题结束！")
            break;
        } else if (text("查看解析").exists()) {
            console.log("专项答题结束，返回！")
            break;
        } else if (text("再来一组").exists()) {
            console.log("专项答题结束，返回！")
            break;
        }
    }
    //回退返回主页 
    goMainPage();
}


/**
 * @description: 听“电台”新闻广播函数  补视听时长
  * @param: null
 * @return: null
 */
function listenToRadio() {
    goMainPage();
    delay(2);
    click("电台");
    delay(1);
    click("听广播");//202012听新闻广播 改为 听广播
    delay(2);
    try {
        if (textContains("最近收听").exists()) {
            click("最近收听");
            console.log("正在收听广播...");
        }
        if (textContains("推荐收听").exists()) {
            click("推荐收听");
            console.log("正在收听广播...");
        }
    } catch (error) {
        console.warn(error);
    }
    delay(2);
    goMainPage();
}

function localChannel1() {
    goMainPage();
    id("home_bottom_tab_button_work").findOne().click();//点击主页正下方的"学习"按钮
    delay(2);
    console.verbose("开始本地频道")
    delay(1);
    if (className("android.widget.TextView").text("综合").exists()) {
        className("android.widget.TextView").text("综合").findOne().parent().parent().child(3).click();
        delay(2);
        if (className("android.widget.TextView").text("切换地区").exists()) {
            className("android.support.v7.widget.RecyclerView").findOne().child(0).click();
            delay(2);
            console.log("返回主界面");
            back();
            className("android.widget.TextView").text("综合").findOne().parent().parent().child(0).click();
        } else {
            className("android.widget.TextView").text("综合").findOne().parent().parent().child(16).click(); //14 15
            delay(2);
            className("android.support.v7.widget.RecyclerView").findOne().child(0).click();
            delay(2);
            console.log("返回主界面");
            back();
            className("android.widget.TextView").text("综合").findOne().parent().parent().child(11).click();
        }
        delay(1);
        id("home_bottom_tab_button_work").findOne().click();
        delay(1);
    } else {
        console.log("请手动点击本地频道！");
    }
}

function video_study() {
    goMainPage();
    desc("电视台").click();
    sleep(random(1000, 1500));
    console.verbose("开始视听学习")
    let scroll = 0;
    let rCount = 0;
    let flag = false;
    while (!flag) {
        if (scroll % 10 == 0) {//每滑动10次随机切换栏目
            let vCatlog = vCat[Math.floor(Math.random() * vCat.length)];
            console.log("进入" + vCatlog);
            click(vCatlog);
            sleep(random(1000, 1500));
        }

        // let stBobao = id("general_card_image_id").find();
        let stBobao = textMatches("(^[0-5][0-9]):([0-5][0-9])$").find();
        for (let item of stBobao) {
            try {
                if (rCount < vCount) {
                    let title = "";
                    /**
                    if (item.parent() && item.parent().parent() && item.parent().parent().parent()) {
                        let root = item.parent().parent().parent();
                        if (root.findOne(text("播报"))) {
                            continue;
                        }

                        if (root.child(0) && root.child(0).child(0) && root.child(0).child(0).child(0)) {
                            title = root.child(0).child(0).child(0).text();
                        }
                    }
                    */
                    if (item.parent() && item.parent().parent()
                        && item.parent().parent().parent()
                        && item.parent().parent().parent().parent()) {
                        let root = item.parent().parent().parent().parent();
                        if (root.findOne(text("播报")) || root.className() != "android.widget.FrameLayout") {
                            continue;
                        }

                        title = root.child(0).child(0).text();
                        if (title == "") {
                            title = root.child(0).child(0).child(0).text();
                        }

                        if (title == "") {
                            title = root.child(0).child(1).child(0).text();
                        }
                    }

                    if (title == null || title.length < 1) {
                        continue;
                    }

                    let isRead = getLearnedArticle(title);
                    // console.log(isRead + "->" + title);

                    if (!isRead) {
                        let hasClicked = false;
                        item = text(title).findOne();
                        if (item.clickable()) {
                            hasClicked = item.click();
                        } else if (item.parent().clickable()) {
                            hasClicked = item.parent().clickable();
                        } else if (item.parent().parent().clickable()) {
                            hasClicked = item.parent().parent().click();
                        } else if (item.parent().parent().parent().clickable()) {
                            hasClicked = item.parent().parent().parent().click();
                        }

                        if (hasClicked) {
                            let arTime = new Date().getTime(); //文章学习开始时间
                            sleep(1000);

                            //进入了非文章页面
                            if (!textContains("欢迎发表你的观点").exists()) {
                                goMainPage();
                                continue;
                            }

                            insertLearnedArticle(title);
                            console.log("正在学习第" + (rCount + 1) + "个视频,标题：", title);
                            video_timing(rCount, vTime);
                            let arEnd = new Date().getTime(); //文章学习结束时间
                            console.log("视频学习了：", (arEnd - arTime) / 1000, "秒");
                            rCount++;
                            goMainPage();
                        }
                    } else {
                        continue;
                    }
                } else {
                    flag = true;
                    break;
                }
            } catch (error) {
                console.warn(error);
            }
        }

        className("android.widget.ListView").scrollForward(); //向下滑动(翻页)
        scroll++;
        console.log("视频学习列表滑动");
        sleep(random(500, 1000));
    }
}

/**
 * @description: “百灵”小视频学习函数
 * @param: vCount,vTime
 * @return: null
 */
function videoStudy_bailing(vCount, vTime) {
    goMainPage();
    h = device.height; //屏幕高
    w = device.width; //屏幕宽
    x = (w / 5) * 3; //横坐标2分之3处
    h1 = (h / 6) * 5; //纵坐标6分之5处
    h2 = (h / 6); //纵坐标6分之1处
    click("百灵");
    sleep(2000);
    var items = ["竖", "炫", "窗", "藏", "靓", "秀", "美食", "推荐"];
    let randomItem = items[Math.floor(Math.random() * items.length)];
    click(randomItem);
    sleep(2000);

    //根据控件搜索视频框，但部分手机不适配，改用下面坐标点击
    if (!className("android.widget.ImageView").depth(26).findOnce().parent().parent().click()) {
        click((w / 2) + random() * 10, h / 4);//坐标点击第一个视频
    }

    sleep(1000);
    for (var i = 0; i < vCount; i++) {
        console.log("正在观看第" + (i + 1) + "个小视频");
        bailing_timing(i, vTime); //观看每个小视频
        if (i != vCount - 1) {
            swipe(x, h1, x, h2, 500); //往下翻（纵坐标从5/6处滑到1/6处）
        }
    }
    back();
    sleep(2000);
}


function article_study() {
    goMainPage();
    desc("工作").click();
    sleep(random(1000, 1500));
    console.verbose("开始选读文章")
    let scroll = 0;
    let rCount = 0;
    let flag = false;
    while (!flag) {
        if (scroll % 10 == 0) {//每滑动10次随机切换栏目
            let aCatlog = aCat[Math.floor(Math.random() * aCat.length)];
            console.log("进入" + aCatlog);
            click(aCatlog);
            sleep(random(1000, 1500));
        }

        let stBobao = className("android.widget.TextView").text("播报").find();
        for (let item of stBobao) {
            try {
                if (rCount < aCount) {
                    let title = "";
                    if (item.parent().parent().parent().parent().clickable()) {
                        title = item.parent().parent().parent().child(0).text();
                    } else if (item.parent().parent().parent().parent().parent().clickable()) {
                        title = item.parent().parent().parent().parent().child(0).text();
                    }

                    if (title == null || title.length < 1) {
                        continue;
                    }

                    let isRead = getLearnedArticle(title);
                    //console.log("isRead=" + isRead);
                    if (!isRead) {
                        let hasClicked = false;
                        if (item.parent().parent().parent().parent().clickable()) {
                            hasClicked = item.parent().parent().parent().parent().click();
                        } else if (item.parent().parent().parent().parent().parent().clickable()) {
                            hasClicked = item.parent().parent().parent().parent().parent().click();
                        }

                        if (hasClicked) {
                            let arTime = new Date().getTime(); //文章学习开始时间
                            sleep(1000);

                            //进入了非文章页面
                            if (!textContains("欢迎发表你的观点").exists()) {
                                goMainPage();
                                continue;
                            }

                            insertLearnedArticle(title);
                            console.log("正在学习第" + (rCount + 1) + "篇文章,标题：", title);
                            article_timing(rCount, aTime);
                            let arEnd = new Date().getTime(); //文章学习结束时间
                            console.log("文章学习了：", (arEnd - arTime) / 1000, "秒");
                            if (rCount < cCount)//收藏分享2篇文章
                            {
                                //收藏+分享 若c运行到此报错请注释本行！
                                article_share(rCount);
                                article_review(rCount);//评论
                            }
                            rCount++;
                            goMainPage();
                        }
                    } else {
                        continue;
                    }
                } else {
                    flag = true;
                    break;
                }
            } catch (error) {
                console.warn(error);
            }
        }

        className("android.widget.ListView").scrollForward(); //向下滑动(翻页)
        scroll++;
        console.log("文章学习列表滑动");
        sleep(random(500, 1000));
    }
}

/**
 * @description: 收藏加分享函数  (收藏+分享)---1+1=2分
 * @param: i-文章标号
 * @return: null
 */
function article_share(i) {
    while (!textContains("欢迎发表你的观点").exists())//如果没有找到评论框则认为没有进入文章界面，一直等待
    {
        delay(1);
        console.log("等待进入文章界面")
    }
    console.log("正在进行第" + (i + 1) + "次收藏和分享...");

    var textOrder = text("欢迎发表你的观点").findOnce().drawingOrder();
    var shareOrder = textOrder + 3;

    var shareIcon = className("ImageView").filter(function (iv) {
        return iv.drawingOrder() == shareOrder;
    }).findOnce();

    shareIcon.click();//点击分享
    while (!textContains("分享到学习强国").exists());//等待弹出分享选项界面
    delay(1);
    click("分享到学习强国");
    delay(2);
    console.info("分享成功!");
    back();//返回文章界面
    delay(1);
}

/**
 * @description: 评论函数---2分
 * @param: i-文章标号
 * @return: null
 */
function article_review(i) {
    while (!textContains("欢迎发表你的观点").exists())//如果没有找到评论框则认为没有进入文章界面，一直等待
    {
        delay(1);
        console.log("等待进入文章界面")
    }
    click("欢迎发表你的观点");//单击评论框
    console.log("正在进行第" + (i + 1) + "次评论...");
    delay(1);
    var num = random(0, commentText.length - 1)//随机数
    setText(commentText[num]);//输入评论内容
    delay(1);
    click("发布");//点击右上角发布按钮
    console.info("评论成功!");
    delay(2);
    click("删除");//删除该评论
    delay(2);
    click("确认");//确认删除
    console.info("评论删除成功!");
    delay(1);
}

/**-------------------------------------公共函数---------------------------------- */
/**
 * @description: 定义延时函数
 * @param: seconds-延迟秒数
 * @return: null
 */
function delay(seconds) {
    sleep(1000 * seconds);//sleep函数参数单位为毫秒所以乘1000
}

/**
 * @description: 获取当天日期字符串函数
 * @param: null
 * @return: s 日期字符串 "2019-xx-xx"
 */
function getTodayDateString() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth();
    var d = date.getDate();
    var s = dateToString(y, m, d); //年-月-日
    return s
}

/**
 * @description: 获取一周前日期字符串函数
 * @param: null
 * @return: s 日期字符串 "2019-xx-xx"
 */
function getBefore30DateString() {
    var date = new Date();
    date.setDate(date.getDate() - 30);
    var y = date.getFullYear();
    var m = date.getMonth();
    var d = date.getDate();
    var s = dateToString(y, m, d); //年-月-日
    return s
}

/**
 * @description: 日期转字符串函数
 * @param: y,m,d 日期数字 2019 1 1
 * @return: s 日期字符串 "2019-xx-xx"
 */
function dateToString(y, m, d) {
    var year = y.toString();
    if ((m + 1) < 10) {
        var month = "0" + (m + 1).toString();
    } else {
        var month = (m + 1).toString();
    }
    if (d < 10) {
        var day = "0" + d.toString();
    } else {
        var day = d.toString();
    }
    var s = year + "-" + month + "-" + day; //年-月-日
    return s;
}

/**
 * 返回到主页
 */
function goMainPage() {
    let flag = false;
    while (!flag) {
        // console.log(desc("工作").exists());
        if (desc("工作").exists()) {
            flag = true;
            break;
        }

        if ("com.alibaba.android.rimet.biz.SplashActivity" == currentActivity()) {
            continue;
        }

        console.log("返回主页...");
        sleep(random(1000, 1500));
        back();
        sleep(random(1000, 1500));
    }
}

/**
 * @description: 生成从minNum到maxNum的随机数
 * @param: minNum-较小的数
 * @param: maxNum-较大的数
 * @return: null
 */
function randomNum(minNum, maxNum) {
    switch (arguments.length) {
        case 1:
            return parseInt(Math.random() * minNum + 1, 10);
        case 2:
            return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
        default:
            return 0;
    }
}

/**------------------------用户信息操作------------------------------------------ */
/**
 * @description: 获取ID号
 * @param: null
 * @return: null
 */
function getUserId() {
    goMainPage();
    while (!id("comm_head_xuexi_mine").exists());
    id("comm_head_xuexi_mine").findOne().click()
    id("my_avatar").waitFor();
    if (id("my_avatar").exists()) {
        id("my_avatar").click();
    }
    id("tv_item_title").className("android.widget.TextView").text("学号").waitFor();
    while (!text("学号").exists());
    idNumber = id("tv_item_content").findOnce(1).parent().child(1).text();
    console.log("学号：", idNumber);
    //获取用户名
    id("tv_item_title").className("android.widget.TextView").text("昵称").waitFor()
    while (!text("昵称").exists());
    name = id("tv_item_content").findOnce(0).parent().child(1).text();
    console.log("用户名：",name);
}

/**
 * @description: 获取积分
 * @param: null
 * @return: null
 */
function getScores() {
    goMainPage();
    console.verbose("正在获取积分...");
    while (!id("comm_head_xuexi_score").exists());
    id("comm_head_xuexi_score").click();
    sleep(1000);
    myScores = {};
    while (!className("android.widget.ListView").exists()) {
        sleep(100);
        if(text("学习积分").exists()) {
            text("学习积分").findOne(500).parent().click();
            sleep(300);
        }
        if(text("刷新").exists()) {
            text("刷新").findOne(500).click();
            console.log("网络较差，建议更换网络运行");
            sleep(300);
        }
    }
    let err = false;
    while (!err) {
        try {
            sleep(1000);
            let scores = className("android.widget.ListView").findOnce().children();
            if (!scores.empty()) {
                for (let s of scores) {
                    let name = s.child(0).child(0).text();
                    let str = s.child(2).text().split("/");
                    let score = parseInt(str[0].match(/[0-9][0-9]*/g));
                    myScores[name] = score;
                }
                err = true;
            }
        } catch (e) {
            sleep(500)
            console.log("重试获取积分");
        }
    }

    // 阅读文章数
    aCount = 12 - myScores["我要选读文章"];
    vCount = (6 - myScores["视听学习"]) * 2;
    lCount = (myScores["挑战答题"] == 6) ? 0 : 1;
    // 视频学习时长
    rTime = (6 - myScores["视听学习时长"]) * 60;

    // 分享与发表观点
    if ((myScores["分享"] == 1) && (myScores["发表观点"] == 1)) {
        cCount = 0;
    } else {
        cCount = 2;
    }

    if (form.dian_full) {
        while (!text("强国城兑福利").exists());
        console.log("正在获取点点通...");

        click("强国城兑福利");

        while (!text("点点通明细").exists());
        click("点点通明细")
        sleep(1000);

        while (!text("今日").exists());
        myDiandian = {
            "有效浏览": 0,
            "有效视听": 0,
            "挑战答题": 0
        };
        sleep(1000)
        try {
            var diandian = className("android.widget.ListView").findOnce(1).children();
            if (!diandian.empty()) {
                for (i = 1; i < diandian.length; i++) {
                    let name = diandian[i].child(2).text();
                    let str = diandian[i].child(3).text();
                    let score = parseInt(str.match(/[0-9][0-9]*/g));
                    myDiandian[name] += score
                }
            }
        } catch (e) { }
        console.log(myDiandian);

        // 视频学习数
        if (vCount < (12 - myDiandian["有效视听"])) {
            vCount = 12 - myDiandian["有效视听"];
        }
        if (aCount < (12 - myDiandian["有效浏览"])) {
            aCount = 12 - myDiandian["有效浏览"];
        }
        // 挑战答题次数
        lCount = 3 - myDiandian["挑战答题"] / 3;
    }

    // 阅读文章时长
    if (aCount > 0) {
        aTime = 27;
    } else {
        aTime = 0;
    }

    if (rTime < 0) {
        rTime = 0;
    }
    // 如果条数够了，时长还不够，学习小视频，三条一个循环
    if (vCount == 0 && rTime > 0) {
        vCount = 3;
    }

    console.log('剩余文章：' + aCount.toString() + '篇')
    console.log('剩余每篇文章学习时长：' + aTime.toString() + '秒')
    console.log('剩余视频：' + vCount.toString() + '个')
    console.log('剩视听学习时长：' + rTime.toString() + '秒')
    console.log('剩余挑战答题：' + lCount + '轮')
}

/*************************************************四人赛、双人对战部分*************************************************/

/**
 * @description: 双人对战
 * @param: null
 * @return: null
 */
function doubleBattle() {
    goMainPage();
    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("每日答题").exists());
    sleep(1000);
    let myImage = className("android.view.View").text("每日答题").findOne();
    myImage = myImage.parent().parent().child(9);
    myImage.click();
    sleep(1000);
    if (text("网络较差").exists()) {
        toastLog("网络较差！重新再来！");
        doubleBattle();
    }
    if(className("android.view.View").text("随机匹配").exists()){
        className("android.view.View").text("随机匹配").findOne().parent().child(0).click();
    } else {
        className("android.view.View").text("").findOne().click();
    }
    console.verbose("开始双人对战");
    var rightCount = 0; //答对题数
    var cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
    while(!className("RadioButton").exists()) {sleep(20);}
    while (rightCount < 5) {
        try {
            cntQuestion = competitionLoop(cntQuestion);
            if (true == cntQuestion.isCorrect) { //如果点击正确答案，正确点击数加1
                rightCount++;
            }
        } catch (error) {
            console.warn(error);
        }
        if (text("100").depth(24).exists() || text("继续挑战").exists()) {
            break;
        }
    }
    if (form.self_kill == true) {
        sleep(4000);
        text("继续挑战").click();
        sleep(1000);
        if(className("android.view.View").text("随机匹配").exists()){
            className("android.view.View").text("随机匹配").findOne().parent().child(0).click();
        } else {
            className("android.view.View").text("").findOne().click();
        }
        console.verbose("开始双人对战");
        rightCount = 0; //答对题数
        cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
        while(!className("RadioButton").exists()) {sleep(20);}
        while (1) {
            try {
                cntQuestion = selfkillLoop(cntQuestion);
            } catch (error) {
                console.warn(error);
            }
            if (text("100").depth(24).exists() || text("继续挑战").exists()) {
                break;
            }
        }
    }
    console.verbose("双人对战结束");
    sleep(5000);
    back();
    sleep(1000);
    back();
    text("退出").click();
    goMainPage();
}

/**
 * @description: 四人赛
 * @param: null
 * @return: null
 */
function fourBattle() {
    goMainPage();
    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("每日答题").exists());
    sleep(1000);
    let myImage = className("android.view.View").text("每日答题").findOne();
    myImage = myImage.parent().parent().child(8);
    myImage.click();
    if (text("网络较差").exists()) {
        toastLog("网络较差！重新再来！");
        competition();
    }
    console.verbose("开始四人赛");
    sleep(1000);
    let lNum = 2; //轮数
    for (i = 0; i < lNum; i++) {
        text("开始比赛").click();
        rightCount = 0; //答对题数
        var cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
        while(!className("RadioButton").exists()) {sleep(20);}
        while (rightCount < 5) {
            try {
                cntQuestion = competitionLoop(cntQuestion);
                if (true == cntQuestion["isCorrect"]) { //如果点击正确答案，正确点击数加1
                    rightCount++;
                }
            } catch (error) {
                console.error(error);
            }

            if (text("100").depth(24).exists() || text("继续挑战").exists()) {
                toastLog("有人100了");
                break;
            }
        }
        sleep(4000);
        text("继续挑战").click();
        sleep(1000);
    }
    if (form.self_kill == true) {
        for (i = 0; i < lNum; i++) {
            text("开始比赛").click();
            cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
            while(!className("RadioButton").exists()) {sleep(20);}
            while (1) {
                try {
                    cntQuestion = selfkillLoop(cntQuestion);
                } catch (error) {
                    console.warn(error);
                }
                if (text("100").depth(24).exists() || text("继续挑战").exists()) {
                    break;
                }
            }
            sleep(4000);
            text("继续挑战").click();
            sleep(1000);
        }
    }
    console.verbose("四人赛结束");
    goMainPage();
}

/**
 * @description: 双人对战答题循环
 * @param: cntQuestion conNum 答题次数 lastQuestion 上次的问题 isCorrect 本次是否答对
 * @return: null
 */
function competitionLoop(cntQuestion) {
    if (true == isNaN(cntQuestion["conNum"]) || cntQuestion["conNum"] == null){
        cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
    }
    var question = "";
    while (question == "") {
        try {
            var OptionArray = [];
            if (className("android.view.View").depth(29).exists() && !text("继续挑战").exists()) {
                retryTimes = 0;
                do {
                    sleep(100);
                    question == "";
                    try {
                        var listArray = className("android.view.View").depth(28).findOne(500).children(); //题目文本列表
                        listArray.forEach(child => {
                            question += child.text();
                        });
                    } catch (error) {
                        question == "";
                        app.sendBroadcast("inspect_layout_bounds");
                        sleep(100);
                    }
                    retryTimes++;
                } while((question == null || question.length < 4) && retryTimes < 20);
                if (question == null || question.length < 4) {
                    question = className("ListView").findOne(500).parent().child(0).text();
                    if (question == null || question.length < 4) {
                        cntQuestion["isCorrect"] = false;
                        console.log("== 第"+(cntQuestion["conNum"] + 1).toString() + "次题目异常 ==");
                        app.sendBroadcast("inspect_layout_bounds");
                        return cntQuestion;
                    }
                }
                if (question == cntQuestion["lastQuestion"]) {
                    question = "";
                    sleep(120);
                } else {
                    cntQuestion["lastQuestion"] = question;
                    console.log("== 第"+(cntQuestion["conNum"] + 1).toString() + "次答题题目 ==");
                    console.log(question);
                    question = deleteNO(question);
                    for (let chuti of chutiIndexArray) {
                        let chutiIndex = question.lastIndexOf(chuti);
                        if (chutiIndex != -1) {
                            question = question.substring(0, chutiIndex - 1);
                        }
                    }

                    question = question.replace(/\s/g, "");
                    var answer = "";
                    if (specialQuest.indexOf(question) <= -1) {
                        answer = getAnswer(question);
                    }
                    var options = [];//选项列表
                    optionValid = false;
                    retryTimes = 0;
                    while (false == optionValid && retryTimes < 30) {
                        var answer_q = "";
                        options = [];
                        try {
                            sleep(100);
                            OptionArray = className("ListView").findOne(500).children(); //题目选项列表
                            if (OptionArray.length > 0) {
                                optionValid = true;
                                OptionArray.forEach(child => {
                                    answer_q = child.child(0).child(1).text();
                                    if (answer_q == null || answer_q.length < 2) {
                                        app.sendBroadcast("inspect_layout_bounds");
                                        optionValid = false;
                                    }
                                    options.push(answer_q);
                                });
                            }
                        } catch (error) {
                            optionValid = false;
                            app.sendBroadcast("inspect_layout_bounds");
                            sleep(100);
                        }
                        retryTimes++;
                    }

                    if (false == optionValid) {
                        console.log((cntQuestion["conNum"] + 1).toString() + ".异常选项：" + options);
                        app.sendBroadcast("inspect_layout_bounds");
                    }

                    // 特殊情况处理
                    if (specialQuest.indexOf(question) > -1) {
                        question = question + deleteNOOpt(options[0]);
                        answer = getAnswer(question);
                    }
                    if (question.length < 4) {
                        console.log((cntQuestion["conNum"] + 1).toString() + ".异常题目：" + question);
                        app.sendBroadcast("inspect_layout_bounds");
                    }

                    if (/^[a-zA-Z]{1}$/.test(answer)) { //如果为ABCD形式
                        var indexAnsTiku = indexFromChar(answer.toUpperCase());
                        answer = options[indexAnsTiku];
                    }
                    if (cntQuestion["conNum"] == 0) {
                        sleep(100);
                    } else {
                        sleep(form.battle_delay);
                    }

                    if (text("100").depth(24).exists()) {
                        toastLog("有人100了");
                        cntQuestion["conNum"]++;
                        cntQuestion["isCorrect"] = true;
                        console.log("-------------------------" + cntQuestion["conNum"] + cntQuestion["isCorrect"]);
                        return cntQuestion;
                    }

                    cntQuestion["isCorrect"] = false;
                    if (answer != "") //如果找到答案
                    {
                        console.info("答案：" + answer);
                        if (textEndsWith(answer).exists()) {
                            cntQuestion["isCorrect"] = textEndsWith(answer).findOne(500).parent().click();
                            if (!cntQuestion["isCorrect"]) {
                                cntQuestion["isCorrect"] = true;
                                app.sendBroadcast("inspect_layout_bounds");
                            }
                            sleep(20);
                            textEndsWith(answer).findOne(500).parent().child(0).click(); //确保点击成功
                        }
                    }

                    if (!cntQuestion["isCorrect"]) //如果没有点击成功
                    {
                        let i = random(0, OptionArray.length - 1);
                        OptionArray[i].child(0).click(); //随意点击一个答案
                        console.error("随机点击第" + i +"个");
                    }
                    cntQuestion["conNum"]++;
                    console.log("-------------------------");
                    return cntQuestion;
                }
            } else if (text("继续挑战").exists()) {
                cntQuestion["isCorrect"] = false;
                console.log("-------------------------");
                return cntQuestion;
            }
        } catch (error) {
            console.error("competitionLoop:" + error.message + '发生在' + error.lineNumber);
            sleep(50);
            cntQuestion["isCorrect"] = false;
            console.log("-------------------------" + cntQuestion["conNum"] + cntQuestion["isCorrect"]);
            app.sendBroadcast("inspect_layout_bounds");
            return cntQuestion;
        }
    }
}

/**
 * @description: 自杀对战答题循环
 * @param: cntQuestion conNum 答题次数 lastQuestion 上次的问题 isCorrect 本次是否答对
 * @return: null
 */
function selfkillLoop(cntQuestion) {
    if (true == isNaN(cntQuestion["conNum"]) || cntQuestion["conNum"] == null){
        cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
    }
    var question = "";
    while (question == "") {
        try {
            var OptionArray = [];
            if (className("android.view.View").depth(29).exists() && !text("继续挑战").exists()) {
                retryTimes = 0;
                do {
                    sleep(100);
                    question == "";
                    try {
                        var listArray = className("android.view.View").depth(28).findOne(500).children(); //题目文本列表
                        listArray.forEach(child => {
                            question += child.text();
                        });
                    } catch (error) {
                        question == "";
                        app.sendBroadcast("inspect_layout_bounds");
                        sleep(100);
                    }
                    retryTimes++;
                } while((question == null || question.length < 4) && retryTimes < 20);
                if (question == null || question.length < 4) {
                    question = className("ListView").findOne(500).parent().child(0).text();
                    if (question == null || question.length < 4) {
                        cntQuestion["isCorrect"] = false;
                        console.log("== 第"+(cntQuestion["conNum"] + 1).toString() + "次题目异常 ==");
                        app.sendBroadcast("inspect_layout_bounds");
                        return cntQuestion;
                    }
                }
                if (question == cntQuestion["lastQuestion"]) {
                    question = "";
                    sleep(120);
                } else {
                    cntQuestion["lastQuestion"] = question;
                    console.log("== 第"+(cntQuestion["conNum"] + 1).toString() + "次答题题目 ==");
                    console.log(question);
                    question = deleteNO(question);
                    for (let chuti of chutiIndexArray) {
                        let chutiIndex = question.lastIndexOf(chuti);
                        if (chutiIndex != -1) {
                            question = question.substring(0, chutiIndex - 1);
                        }
                    }

                    question = question.replace(/\s/g, "");
                    var answer = "";
                    if (specialQuest.indexOf(question) <= -1) {
                        answer = getAnswer(question);
                    }
                    var options = [];//选项列表
                    optionValid = false;
                    retryTimes = 0;
                    while (false == optionValid && retryTimes < 30) {
                        var answer_q = "";
                        options = [];
                        try {
                            sleep(100);
                            OptionArray = className("ListView").findOne(500).children(); //题目选项列表
                            if (OptionArray.length > 0) {
                                optionValid = true;
                                OptionArray.forEach(child => {
                                    answer_q = child.child(0).child(1).text();
                                    if (answer_q == null || answer_q.length < 2) {
                                        app.sendBroadcast("inspect_layout_bounds");
                                        optionValid = false;
                                    }
                                    options.push(answer_q);
                                });
                            }
                        } catch (error) {
                            optionValid = false;
                            app.sendBroadcast("inspect_layout_bounds");
                            sleep(100);
                        }
                        retryTimes++;
                    }

                    if (false == optionValid) {
                        console.log((cntQuestion["conNum"] + 1).toString() + ".异常选项：" + options);
                        app.sendBroadcast("inspect_layout_bounds");
                    }

                    // 特殊情况处理
                    if (specialQuest.indexOf(question) > -1) {
                        question = question + deleteNOOpt(options[0]);
                        answer = getAnswer(question);
                    }
                    if (question.length < 4) {
                        console.log((cntQuestion["conNum"] + 1).toString() + ".异常题目：" + question);
                        app.sendBroadcast("inspect_layout_bounds");
                    }

                    if (/^[a-zA-Z]{1}$/.test(answer)) { //如果为ABCD形式
                        var indexAnsTiku = indexFromChar(answer.toUpperCase());
                        answer = options[indexAnsTiku];
                    }
                    if (cntQuestion["conNum"] == 0) {
                        sleep(100);
                    } else {
                        sleep(form.battle_delay);
                    }

                    if (text("100").depth(24).exists()) {
                        toastLog("有人100了");
                        cntQuestion["conNum"]++;
                        cntQuestion["isCorrect"] = true;
                        console.log("-------------------------" + cntQuestion["conNum"] + cntQuestion["isCorrect"]);
                        return cntQuestion;
                    }

                    cntQuestion["isCorrect"] = false;
                    if (answer != "") //如果找到答案
                    {
                        console.info("答案：" + answer);
                        if (textEndsWith(answer).exists()) {
                            if (options[0].includes(answer)) {
                                cntQuestion["isCorrect"] = textEndsWith(options[1]).findOne(500).parent().click();
                            } else {
                                cntQuestion["isCorrect"] = textEndsWith(options[0]).findOne(500).parent().click();
                            }//确保点击一个错误答案
                        }
                    }

                    if (!cntQuestion["isCorrect"]) //如果没有点击成功
                    {
                        let i = random(0, OptionArray.length - 1);
                        OptionArray[i].child(0).click(); //随意点击一个答案
                        console.error("随机点击第" + i +"个");
                    }
                    cntQuestion["isCorrect"] = false;
                    cntQuestion["conNum"]++;
                    console.log("-------------------------");
                    return cntQuestion;
                }
            } else if (text("继续挑战").exists()) {
                cntQuestion["isCorrect"] = false;
                console.log("-------------------------");
                return cntQuestion;
            }
        } catch (error) {
            console.error("competitionLoop:" + error.message + '发生在' + error.lineNumber);
            sleep(50);
            cntQuestion["isCorrect"] = false;
            console.log("-------------------------" + cntQuestion["conNum"] + cntQuestion["isCorrect"]);
            app.sendBroadcast("inspect_layout_bounds");
            return cntQuestion;
        }
    }
}

/**
 * @description: 答题四人赛、双人对战，去掉题目和答案前面的序号
 * @param: str 问题或答案
 * @return: 去掉序号后的题目或答案
 */
function deleteNO(str) {
    if (/^\d+\. /.test(str)) {
        var strNO = /^\d+\. /.exec(str);
        //console.log("标号部分:"+ strNO[0] + " 长度:" + strNO[0].length.toString());
        return str.slice(strNO[0].length);
    } else {
        return str;
    }
}

function deleteNOOpt(str) {
        return str.slice(3);
}
/**----------------------------------挑战答题-------------------------------------------- */
/**
 * @description: 挑战答题
 * @param: null
 * @return: null
 */
function challengeQuestion() {
    goMainPage();

    id("comm_head_xuexi_mine").click();
    while (!textContains("我要答题").exists());
    sleep(1000);
    click("我要答题");
    while (!text("每日答题").exists());
    sleep(1000);
    let myImage = className("android.view.View").text("每日答题").findOne();
    myImage = myImage.parent().parent().child(10);
    myImage.click();
    console.verbose("开始挑战答题")
    sleep(4000);
    let conNum = 0; //连续答对的次数
    let lNum = 1; //轮数
    while (true) {
        //无限刷题模式
        if (form.challenge_all && !allRun) {
            qCount = 99999;
        }else{
            qCount = random(5, 10);//随机答对题数
        }

        challengeQuestionLoop(conNum, qCount);
        sleep(random(3000, 5000));
        if (text("v5IOXn6lQWYTJeqX2eHuNcrPesmSud2JdogYyGnRNxujMT8RS7y43zxY4coWepspQkvw" +
            "RDTJtCTsZ5JW+8sGvTRDzFnDeO+BcOEpP0Rte6f+HwcGxeN2dglWfgH8P0C7HkCMJOAAAAAElFTkSuQmCC").exists()) //遇到?号，则答错了,不再通过结束本局字样判断
        {
            if ((lNum >= lCount && conNum >= qCount)) {
                console.verbose("挑战答题结束！");
                goMainPage();
                break;
            } else {
                console.verbose("等10秒开始下一轮...")
                sleep(3000); //等待10秒才能开始下一轮
                if (textStartsWith("确定退出答题练习").exists()) {
                    click("退出");
                }
                back();
                sleep(1000);
                back();
                while (!text("每日答题").exists());
                sleep(1000);
                let myImage = className("android.view.View").text("每日答题").findOne();
                myImage = myImage.parent().parent().child(10);
                myImage.click();
                sleep(4000);
                if (conNum >= qCount) {
                    lNum++;
                }
                conNum = 0;
            }
            console.warn("第" + lNum.toString() + "轮开始...")
        } else //答对了
        {
            conNum++;
        }
    }
}

/**
 * @description: 每次答题循环
 * @param: conNum 连续答对的次数
 * @return: null
 */
function challengeQuestionLoop(conNum, qCount) {
    try {
        if (conNum >= qCount) //答题次数足够退出，每轮5次
        {
            let listArray = className("ListView").findOnce().children(); //题目选项列表
            let i = random(0, listArray.length - 1);
            console.log("本轮次数足够，随机点击一个答案，答错进入下一轮");
            listArray[i].child(0).click(); //随意点击一个答案
            console.log("----------------------------------");
            return;
        }

        if (className("ListView").exists()) {
            var question = className("ListView").findOnce().parent().child(0).text();
        } else {
            console.error("提取题目失败!");
            let listArray = className("ListView").findOnce().children(); //题目选项列表
            let i = random(0, listArray.length - 1);
            console.log("随机点击一个");
            listArray[i].child(0).click(); //随意点击一个答案
            return;
        }


        for (let chuti of chutiIndexArray) {
            let chutiIndex = question.lastIndexOf(chuti);
            if (chutiIndex != -1) {
                question = question.substring(0, chutiIndex - 1);
            }
        }

        question = question.replace(/\s/g, "");

        var options = []; //选项列表
        if (className("ListView").exists()) {
            className("ListView").findOne().children().forEach(child => {
                var answer_q = child.child(0).child(1).text();
                options.push(answer_q);
            });
        } else {
            console.error("答案获取失败!");
            return;
        }

        // 特殊情况外理
        if (specialQuest.indexOf(question) > -1) {
            question = question + options[0];
        }

        var answer = getAnswer(question);
        console.log((conNum + 1).toString() + ".题目：" + question);

        if (/^[a-zA-Z]{1}$/.test(answer)) { //如果为ABCD形式
            var indexAnsTiku = indexFromChar(answer.toUpperCase());
            answer = options[indexAnsTiku];
        }

        let hasClicked = false;
        var listArray = className("ListView").findOnce().children(); //题目选项列表
        if ((answer == "") || !textEndsWith(answer).exists()) //如果没找到答案
        {
            let i = random(0, listArray.length - 1);
            console.error("没有找到答案，随机点击一个");
            listArray[i].child(0).click(); //随意点击一个答案
            hasClicked = true;
            var delayTime = 500;
            var myColor = "#44BF78";
            var myThreshold = 15;
            var correctAns = findCorrectAnswer(delayTime, myColor, myThreshold, listArray, options);

            if (correctAns != "") //如果答案不是null，就更新题库
            {
                if (answer == "") {
                    var sql = "INSERT INTO tiku (question, answer) VALUES ('" + question + "', '" + correctAns + "')";
                } else {
                    var sql = "UPDATE tiku SET answer='" + correctAns + "' WHERE question LIKE '" + question + "%'";
                }
                executeSQL(sql);
                console.log("更新题库答案...");
            }
            console.log("-------------------------------");
        } else {//如果找到了答案
            console.info("答案：" + answer);
            text(answer).click();
            hasClicked = true;
            console.log("-------------------------------");
        }
        if (!hasClicked) { //如果没有点击成功
            console.error("未能成功点击，随机点击一个");
            let i = random(0, listArray.length - 1);
            listArray[i].child(0).click(); //随意点击一个答案
            console.log("-------------------------------");
        }
        return false;
    } catch (error) {
        console.error("challengeQuestionLoop:" + error)
    }
}

/**
 * @description: 返回字段首字母序号
 * @param: str
 * @return: int 字母序号
 */
function indexFromChar(str) {
    return str.charCodeAt(0) - "A".charCodeAt(0);
}


/**
 * @description: 答错后查找正确答案
 * @param: delayTime, myColor, myThreshold, listArray, options
 * @return: correctAns 正确答案
 */
function findCorrectAnswer(delayTime, myColor, myThreshold, listArray, options) {
    console.hide(); //隐藏console控制台窗口
    sleep(delayTime); //等待截屏
    var img = captureScreen(); //截个屏
    console.show(); //显示console控制台窗口
    // 查找绿色答案#f24650
    let answer = "";
    listArray.some(item => {
        var listBounds = item.bounds();
        var point = findColor(img, myColor, {
            region: [listBounds.left, listBounds.top, listBounds.right - listBounds.left, listBounds.bottom - listBounds.top],
            threshold: myThreshold
        });
        if (point) {
            answer = options[listArray.indexOf(item)];
        }
    });
    return answer;
}

/**------------------------------计时弹窗--------------------------------------- */
/**
 * @description: 文章学习计时(弹窗)函数
 * @param: n-文章标号 seconds-学习秒数
 * @return: null
 */
function article_timing(n, seconds) {
    h = device.height;//屏幕高
    w = device.width;//屏幕宽
    x = (w / 3) * 2;
    h1 = (h / 6) * 5;
    h2 = (h / 6);
    seconds = seconds + random(0,10);
    for (var i = 0; i < seconds; i++) {
       delay(1);
        while (!textContains("欢迎发表你的观点").exists())//如果离开了文章界面则一直等待
        {
            console.error("当前已离开第" + (n + 1) + "文章界面，请重新返回文章页面...");
            delay(2);
         if(id("home_bottom_tab_button_work").exists()){
            id("home_bottom_tab_button_work").findOne().click();
             delay(1);
             num = random(0, commentText.length - 1) ; //重取随机数
            var date_string = getTodayDateString();
             /*s = date_string;*/
            s = "“学习强国”学习平台";
            var aCatlog = aCat[num] ;
            click(aCatlog);
            console.log('文章类别：' + aCatlog + '关键词：'+ s)
            delay(2);
            click(s);
            delay(2);
            break;//break结束当前循环，continue继续执行当前循环，该命令导致手动进入文章无效 待修正
            }
        }
        if (i % 5 == 0)
        {
            console.info("第" + (n + 1) + "篇文章已经学习" + (i + 1) + "秒,剩余" + (seconds - i - 1) + "秒!");
            toast("防息屏弹窗,请无视");
            if (i <= seconds / 2) {//每10秒滑动一次，如果android版本<7.0请将此滑动代码删除
                swipe(x, h1, x, h2, 500);//向下滑动
            } else {
                swipe(x, h2, x, h1, 500);//向上滑动
            }
        }
    }
}

/**
 * @description: 视频学习计时(弹窗)函数
 * @param: n-视频标号 seconds-学习秒数
 * @return: null
 */
function bailing_timing(n, seconds) {
    seconds = randomNum(seconds - 5, seconds + 5);
    for (var i = 0; i * 5 < seconds; i++) {
        while (!textContains("分享").exists()) //如果离开了百灵小视频界面则一直等待
        {
            console.error("当前已离开第" + (n + 1) + "个百灵小视频界面，请重新返回视频");
            sleep(2000);
        }


        if (seconds > ((i + 1) * 5)) {
            sleep(5000);
            console.info("第" + (n + 1) + "个小视频已经观看" + ((i + 1) * 5) + "秒,剩余" + (seconds - (i + 1) * 5) + "秒!");
        } else {
            sleep((seconds - i * 5) * 1000);
        }

        if (i % 10 == 0) //每10秒滑动一次，如果android版本<7.0请将此滑动代码删除
        {
            toast("这是防息屏toast,请忽视-。-");
        }
    }
}

/**
 * @description: 新闻联播小视频学习计时(弹窗)函数
 * @param: n-视频标号 seconds-学习秒数
 * @return: null
 */
function video_timing(n, seconds) {
    seconds = randomNum(seconds - 5, seconds + 5);
    for (var i = 0; i * 5 < seconds; i++) {
        while (!textContains("欢迎发表你的观点").exists()) //如果离开了联播小视频界面则一直等待
        {
            console.error("当前已离开第" + (n + 1) + "个新闻视频界面，请重新返回视频");
            sleep(2000);
        }

        if (textContains("继续播放").exists()) {
            click("继续播放");
        }

        if (seconds > ((i + 1) * 5)) {
            sleep(5000);
            console.info("第" + (n + 1) + "个新闻视频已经观看" + ((i + 1) * 5) + "秒,剩余" + (seconds - (i + 1) * 5) + "秒!");
        } else {
            sleep((seconds - i * 5) * 1000);
        }
    }
}

/**
 * @description: 广播学习计时(弹窗)函数
 * @param: r_time-已经收听的时间 seconds-学习秒数
 * @return: null
 */
function radio_timing(r_time, seconds) {
    for (var i = 0; i < seconds; i++) {
        sleep(1000);
        if (i % 5 == 0) //每5秒打印一次信息
        {
            console.info("广播已经收听" + (i + 1 + r_time) + "秒,剩余" + (seconds - i - 1) + "秒!");
        }
        if (i % 10 == 0) //每15秒弹一次窗防止息屏
        {
            toast("这是防息屏toast,请忽视-。-");
        }
    }
}

/**----------------------------每日答题----------------------------------------- */
/**
 * @description: 每日答题循环
 * @param: null
 * @return: null
 */
function dailyQuestionLoop() {
    if (textStartsWith("填空题").exists()) {
        var questionType = "填空题："; //questionType题型是什么
        var questionArray = getFitbQuestion();
        //console.log('填空题')
    } else if (textStartsWith("多选题").exists()) {
        var questionType = "多选题：";
        var questionArray = getChoiceQuestion();
        //console.log('选择题')
    } else if (textStartsWith("单选题").exists()) {
        var questionType = "单选题：";
        var questionArray = getChoiceQuestion();
    }

    var blankArray = [];
    var question = "";
    questionArray.forEach(item => {
        if (item != null && item.charAt(0) == "|") { //是空格数
            blankArray.push(item.substring(1));
        } else { //是题目段
            question += item;
        }
    });

    // 特殊情况外理
    if (specialQuest.indexOf(question) > -1) {
        question = question + className("ListView").findOnce().child(0).child(0).child(2).text();
    }

    for (let chuti of chutiIndexArray) {
        let chutiIndex = question.lastIndexOf(chuti);
        if (chutiIndex != -1) {
            question = question.substring(0, chutiIndex - 1);
        }
    }

    question = question.replace(/\s/g, "");
    console.log(questionType + question);
    var ansTiku = getAnswer(question);

    var answer = ansTiku.replace(/(^\s*)|(\s*$)/g, "");

    if (textStartsWith("填空题").exists()) {
        if (answer == "") {
            var tipsStr = getTipsStr();
            answer = getAnswerFromTips(questionArray, tipsStr);
            console.info("提示中的答案：" + answer);
            setText(0, answer.substr(0, blankArray[0]));
            if (blankArray.length > 1) {
                for (var i = 1; i < blankArray.length; i++) {
                    setText(i, answer.substr(blankArray[i - 1], blankArray[i]));
                }
            }
        } else {
            console.info("答案：" + answer);
            setText(0, answer.substr(0, blankArray[0]));
            if (blankArray.length > 1) {
                for (var i = 1; i < blankArray.length; i++) {
                    setText(i, answer.substr(blankArray[i - 1], blankArray[i]));
                }
            }
        }
    } else if (textStartsWith("多选题").exists() || textStartsWith("单选题").exists()) {
        if (answer == "") {
            var tipsStr = getTipsStr();
            answer = clickByTips(tipsStr);
            console.info("提示中的答案：" + answer);
        } else {
            console.info("答案：" + ansTiku);
            clickByAnswer(answer);
        }
    }

    sleep(random(500, 2000));
    if (text("确定").exists()) {
        text("确定").click();
        delay(0.5);
    } else if (text("下一题").exists()) {
        click("下一题");
        delay(0.5);
    } else if (text("完成").exists()) {
        text("完成").click();
        delay(0.5);
    } else {
        console.warn("未找到右上角确定按钮控件，根据坐标点击");
        click(device.width * 0.85, device.height * 0.06); //右上角确定按钮，根据自己手机实际修改
    }

    console.log("---------------------");
    sleep(random(500, 2000));
}

/**
 * @description: 获取填空题题目数组
 * @param: null
 * @return: questionArray
 */
function getFitbQuestion() {
    var questionCollections = className("EditText").findOnce().parent().parent();
    var questionArray = [];
    var findBlank = false;
    var blankCount = 0;
    var blankNumStr = "";
    var i = 0;
    questionCollections.children().forEach(item => {
        if (item.className() != "android.widget.EditText") {
            if (item.text() != "") { //题目段
                if (findBlank) {
                    blankNumStr = "|" + blankCount.toString();
                    questionArray.push(blankNumStr);
                    findBlank = false;
                }
                questionArray.push(item.text());
            } else {
                findBlank = true;
                blankCount = (className("EditText").findOnce(i).parent().childCount() - 1);
                i++;
            }
        }
    });
    return questionArray;
}

/**
 * @description: 获取选择题题目数组
 * @param: null
 * @return: questionArray
 */
function getChoiceQuestion() {
    var questionCollections = className("ListView").findOnce().parent().child(1);
    var questionArray = [];
    questionArray.push(questionCollections.text());
    return questionArray;
}


/**
 * @description: 根据提示点击选择题选项
 * @param: tipsStr
 * @return: clickStr
 */
function clickByTips(tipsStr) {
    var clickStr = "";
    var correctAnswerStr = "";
    var isFind = false;
    if (className("ListView").exists()) {
        var listArray = className("ListView").findOne().children();
        listArray.forEach(item => {
            var ansStr = item.child(0).child(2).text();
            if (tipsStr.indexOf(ansStr) >= 0) {
                item.child(0).click();
                clickStr += item.child(0).child(1).text().charAt(0);
                correctAnswerStr = ansStr;
                isFind = true;
            }
        });
        if (!isFind) { //没有找到 随机点击一个
            console.error("未能成功点击，随机点击一个");
            let i = random(0, listArray.length - 1);
            listArray[i].child(0).click();
            clickStr += listArray[i].child(0).child(1).text().charAt(0);
            correctAnswerStr = listArray[i].child(0).child(2).text();
        }
    }
    if (textStartsWith("单选题").exists()) {
        return correctAnswerStr;
    } else {
        return clickStr;
    }
}


/**
 * @description: 根据答案点击选择题选项
 * @param: answer
 * @return: null
 */
function clickByAnswer(answer) {
    var hasClicked = false;
    if (className("ListView").exists()) {
        var listArray = className("ListView").findOnce().children();
        listArray.forEach(item => {
            var listIndexStr = item.child(0).child(1).text().charAt(0);
            //单选答案为非ABCD
            var listDescStr = item.child(0).child(2).text();
            // console.log(listDescStr)
            if (answer == listDescStr) {
                item.child(0).click();
                hasClicked = true;
            } else if (answer.indexOf(listIndexStr) >= 0) {
                item.child(0).click();
                hasClicked = true;
            }
        });
        if (!hasClicked) { //没有找到 随机点击一个
            console.error("未能成功点击，随机点击一个");
            let i = random(0, listArray.length - 1);
            listArray[i].child(0).click();
        }
    }
}

/**
 * @description: 从提示中获取填空题答案
 * @param: timu, tipsStr
 * @return: ansTips
 */
function getAnswerFromTips(timu, tipsStr) {
    var ansTips = "";
    for (var i = 1; i < timu.length - 1; i++) {
        if (timu[i].charAt(0) == "|") {
            var blankLen = timu[i].substring(1);
            var indexKey = tipsStr.indexOf(timu[i + 1]);
            var ansFind = tipsStr.substr(indexKey - blankLen, blankLen);
            ansTips += ansFind;
        }
    }
    return ansTips;
}

/**
 * @description: 获取提示字符串
 * @param: null
 * @return: tipsStr
 */
function getTipsStr() {
    var tipsStr = "";
    while (tipsStr == "") {
        if (text("查看提示").exists()) {
            var seeTips = text("查看提示").findOnce();
            seeTips.click();
            delay(1);
            click(device.width * 0.5, device.height * 0.41);
            delay(1);
            click(device.width * 0.5, device.height * 0.35);
        } else {
            console.error("未找到查看提示");
        }
        if (text("提示").exists()) {
            var tipsLine = text("提示").findOnce().parent();
            //获取提示内容
            if (tipsLine.parent().child(1).child(0).text() == "") {
                var tipsViewArray = tipsLine.parent().child(1).child(0).children();
            } else {
                var tipsViewArray = tipsLine.parent().child(1).children();
            }
            tipsViewArray.forEach(item => {
                if (item.text().substr(0, 2) != "--" || item.text().substr(0, 2) != "来源") {
                    tipsStr += item.text();
                }
            })
            // console.log("提示：" + tipsStr);
            //关闭提示
            tipsLine.child(1).click();
            break;
        }
        delay(1);
    }
    return tipsStr;
}

/**-----------------------------各类答题----------------------------------------- */
function answerQuestion() {
    console.setPosition(0, device.height / 2);
    console.show();
    delay(1);

    if (className("android.view.View").text("开始比赛").exists()) {//四人赛开始页
        className("android.view.View").text("开始比赛").click();
        console.verbose("开始四人赛");
        while(!className("RadioButton").exists()) {sleep(20);}
        battle();
        console.verbose("四人赛结束");
    } else if (className("android.view.View").text("随机匹配").exists()) {//双人对战开始页
        className("android.view.View").text("").findOne().click();
        console.verbose("开始双人对战答题");
        while(!className("RadioButton").exists()) {sleep(20);}
        battle();
        console.verbose("双人对战结束");
        sleep(5000);
        back();
        sleep(1000);
        back();
        text("退出").click();
        delay(1)
        while (!text("答题练习").exists()) {
            back();
            delay(1)
        }
    } else if ((textStartsWith("填空题").exists() || textStartsWith("多选题").exists() || textStartsWith("单选题").exists())) {//每日答题等有单选或多选题
        console.verbose("开始 每日/每周/专项 答题");
        while ((textStartsWith("填空题").exists() || textStartsWith("多选题").exists() || textStartsWith("单选题").exists())) {
            dailyQuestionLoop();
        }
        console.verbose("每日/每周/专项 答题结束");
        delay(1)
        while (!text("答题练习").exists()) {
            back();
            delay(1)
        }
    } else if (className("ListView").exists()) {//答题界面
        var questionNum = className("ListView").findOnce().parent().child(0).text().substring(0, 2); //四人赛和对战题目前带序号1.
        if (questionNum != "1.") {
            //不含序号“1.”，且不提示单选或多选题，则判断为挑战答题界面
            console.verbose("准备开始挑战答题");
            let conNum = 0; //连续答对的次数
            let lNum = 1; //轮数
            while (true) {
                //无限刷题模式
                if (form.challenge_all) {
                    qCount = 99999;
                } else {
                    qCount = random(5, 10);//随机答对题数
                }

                //console.log("qCount=" + qCount);
                challengeQuestionLoop(conNum, qCount);
                sleep(random(3000, 5000));
                if (text("v5IOXn6lQWYTJeqX2eHuNcrPesmSud2JdogYyGnRNxujMT8RS7y43zxY4coWepspQkvw" +
                    "RDTJtCTsZ5JW+8sGvTRDzFnDeO+BcOEpP0Rte6f+HwcGxeN2dglWfgH8P0C7HkCMJOAAAAAElFTkSuQmCC").exists()) //遇到?号，则答错了,不再通过结束本局字样判断
                {
                    if (conNum >= qCount) {
                        console.verbose("挑战答题结束！");
                        break;
                    } else {
                        console.verbose("等10秒开始下一轮...")
                        sleep(3000); //等待10秒才能开始下一轮
                        if (textStartsWith("确定退出答题练习").exists()) {
                            click("退出");
                        }
                        back();
                        sleep(1000);
                        back();
                        while (!text("每日答题").exists());
                        sleep(1000);
                        let myImage = className("android.view.View").text("每日答题").findOne();
                        myImage = myImage.parent().parent().child(10);
                        myImage.click();
                        sleep(4000);
                        conNum = 0;
                    }
                    console.warn("第" + lNum + "轮开始...")
                } else //答对了
                {
                    conNum++;
                }
            }
        }
        delay(1)
        while (!text("答题练习").exists()) {
            back();
            delay(1)
        }
    } else {
        console.warn("没有找到答题开始页！");
        //打开我要答题界面
        console.warn("请手动打开答题界面再重试 !");
        console.warn("四人赛和双人挑战在 开始挑战/对战 的界面）");
    }
}


function battle() {
    rightCount = 0; //答对题数
    var cntQuestion = {"conNum":0, "lastQuestion":"", "isCorrect":false};
    while (rightCount < 10) {
        try {
            if (form.self_kill == true) {
                cntQuestion = selfkillLoop(cntQuestion);
            } else {
                cntQuestion = competitionLoop(cntQuestion);
            }
            if (cntQuestion["isCorrect"]) { //如果点击正确答案，正确点击数加1
                rightCount++;
            }
        } catch (error) {
            console.warn(error);
        }
        if (text("100").depth(24).exists() || text("继续挑战").exists()) {
            break;
        }
    }
}

/**-----------------------数据库操作--------------------------------------- */
/**
 * @description: 判断题库是否存在
 * @param: null
 * @return: boolean
 */
function judge_tiku_existence() {
    if (!files.exists(path)) {
        console.error("未找到题库！请将题库文件放置与js文件同一目录下再运行！");
        return false;
    }
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    var createTable = "CREATE TABLE IF NOT EXISTS tiku(question CHAR(253),option CHAR(100), answer CHAR(100),wrongAnswer CHAR(100));";
    db.execSQL(createTable);

    db.close();
    return true;
}

/**
 * @description: 增加或更新数据库
 * @param: title,idNumber,date
 * @return: res
 */
function getLearnedArticle(title) {
    if (!files.exists(path)) {
        console.error("未找到题库!请将题库放置与js同一目录下");
    }
    //创建或打开数据库
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    var createTable = "CREATE TABLE IF NOt EXISTS learnedArticles(title CHAR(500),id_number CHAR(15),date_string CHAR(15));";
    db.execSQL(createTable);
    var sql = "SELECT * FROM  learnedArticles WHERE title = '" + title + "' AND id_number = '" + idNumber + "'";
    var cursor = db.rawQuery(sql, null);
    var res = cursor.moveToFirst();
    cursor.close();
    db.close();
    return res;
}

function insertLearnedArticle(title) {
    if (!files.exists(path)) {
        console.error("未找到题库!请将题库放置与js同一目录下");
    }
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    var createTable = "CREATE TABLE IF NOt EXISTS learnedArticles(title CHAR(253),id_number CHAR(15), date_string CHAR(15));";
    db.execSQL(createTable);
    var sql = "INSERT INTO learnedArticles VALUES ('" + title + "','" + idNumber + "','" + current_date + "')";
    db.execSQL(sql);

    sql = "SELECT COUNT(*) FROM learnedArticles WHERE id_number = '" + idNumber + "';";
    var cursor = db.rawQuery(sql, null);
    cursor.moveToFirst();
    let sCount = cursor.getLong(0);
    console.warn("插入已学表中，共", sCount, "条");
    db.close();
}

/**
 * 删除30天之前的阅读记录
 */
function cleanLearnedArticle() {
    if (!files.exists(path)) {
        console.error("未找到题库!请将题库放置与js同一目录下");
    }
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    var createTable = "CREATE TABLE IF NOt EXISTS learnedArticles(title CHAR(253), id_number CHAR(15), date_string CHAR(15));";

    db.execSQL(createTable);
    var cleanTable = "DELETE FROM learnedArticles WHERE date_string < '" + getBefore30DateString() + "';";
    try {
        db.execSQL(cleanTable);
        console.info("清空表");
    } catch (e) {
        console.error(e);
    }
    db.close();
}

/**
 * @description: 从数据库中搜索答案
 * @param: question 问题
 * @return: answer 答案
 */
function getAnswer(question) {
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    let sql = "SELECT answer FROM tiku WHERE question LIKE '" + question + "%'"
    var cursor = db.rawQuery(sql, null);
    let answer = "";
    if (cursor.moveToFirst()) {
        answer = cursor.getString(0);
    } else {
        let netTiku = "http://sg89.cn/api/tk1.php"; //在线题库
        try {
            let zxda = http.post(netTiku, {//在线答案
                "t": "da",
                "q": question
            });
            let zxanswer = zxda.body.json();
            if (zxanswer.code == -1) { //未找到答案
                answer = '';
            } else {//找到答案 (0||1)
                answer = zxanswer.as;//在线答案
                if (answer != undefined) {
                    //添加或更新本地题库答案
                    console.log("网络答案:" + answer);
                    sql = "INSERT INTO tiku (question, answer) VALUES ('" + question + "', '" + answer + "')";
                    db.execSQL(sql);
                    cursor = db.rawQuery(sql, null);
                }
            }
        } catch (e) {
            console.error("网络请求出错，请检查! " + e);
            answer = '';
        }
    }
    cursor.close();
    db.close();
    return answer;
}

function executeSQL(sqlstr) {
    if (!files.exists(path)) {
        files.createWithDirs(path);
    }
    //创建或打开数据库
    var db = SQLiteDatabase.openOrCreateDatabase(path, null);
    db.execSQL(sqlstr);
    db.close();
}
